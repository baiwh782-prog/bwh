import { useEffect, useRef, useState } from "react";
import { ArrowUp, Check, Copy, Menu, Plus, RotateCcw, Square, Trash2, X } from "lucide-react";
import { Markdown } from "@/components/markdown";
import { streamChat } from "@/lib/chat-api";
import {
  formatWhen,
  formatTimestamp,
  useChatStore,
  type ChatMessage,
  type Thread,
  type Tone,
} from "@/lib/chat-store";

const TONES: { id: Tone; label: string }[] = [
  { id: "brief", label: "速答" },
  { id: "chat", label: "闲谈" },
  { id: "deep", label: "深谈" },
];

const STARTERS = [
  "帮我把一段话改得更干净",
  "用一个生活里的比喻讲清楚一件难事",
  "我在两个选择之间卡住了",
  "给今天写一句不矫情的小结",
];

const MAX_INPUT = 4000;

function historyOf(messages: ChatMessage[]) {
  return messages
    .filter((m) => m.content.trim() && m.status !== "streaming" && m.status !== "error")
    .slice(-16)
    .map((m) => ({ role: m.role, content: m.content }));
}

export function ChatApp() {
  const threads = useChatStore((s) => s.threads);
  const activeId = useChatStore((s) => s.activeId);
  const newThread = useChatStore((s) => s.newThread);
  const setActive = useChatStore((s) => s.setActive);
  const setTone = useChatStore((s) => s.setTone);
  const removeThread = useChatStore((s) => s.removeThread);
  const commitExchange = useChatStore((s) => s.commitExchange);
  const patchMessage = useChatStore((s) => s.patchMessage);
  const dropMessage = useChatStore((s) => s.dropMessage);

  const [ready, setReady] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const busyRef = useRef(false);
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef(true);
  const boxRef = useRef<HTMLTextAreaElement | null>(null);

  const active = threads.find((t) => t.id === activeId) ?? null;
  const ordered = [...threads].sort((a, b) => b.updatedAt - a.updatedAt);

  useEffect(() => {
    let alive = true;
    void Promise.resolve(useChatStore.persist.rehydrate()).then(() => {
      if (!alive) return;
      const state = useChatStore.getState();
      const exists = state.threads.some((t) => t.id === state.activeId);
      if (!exists) {
        useChatStore.setState({ activeId: state.threads[0]?.id ?? null });
      }
      setReady(true);
    });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!stickRef.current) return;
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [active?.messages, sending]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function focusComposer() {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    boxRef.current?.focus();
  }

  function resizeBox() {
    const el = boxRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }

  function openThread(id: string) {
    setActive(id);
    setDraft("");
    setSidebarOpen(false);
    setPendingDelete(null);
    stickRef.current = true;
    focusComposer();
  }

  function startNew() {
    const id = newThread();
    setDraft("");
    setSidebarOpen(false);
    setPendingDelete(null);
    stickRef.current = true;
    useChatStore.setState({ activeId: id });
    focusComposer();
  }

  async function run(threadId: string, history: { role: "user" | "assistant"; content: string }[]) {
    const tone = useChatStore.getState().threads.find((t) => t.id === threadId)?.tone ?? "chat";
    const asstId = crypto.randomUUID();
    const placeholder: ChatMessage = {
      id: asstId,
      role: "assistant",
      content: "",
      createdAt: Date.now(),
      status: "streaming",
    };
    commitExchange(threadId, [placeholder]);
    stickRef.current = true;
    setSending(true);
    const ac = new AbortController();
    abortRef.current = ac;
    let acc = "";
    try {
      await streamChat({ tone, messages: history }, ac.signal, (delta) => {
        acc += delta;
        patchMessage(threadId, asstId, { content: acc, status: "streaming" });
      });
      patchMessage(threadId, asstId, {
        content: acc || "（没有写下内容）",
        status: acc ? "done" : "error",
      });
    } catch (err) {
      if (ac.signal.aborted) {
        if (acc) patchMessage(threadId, asstId, { content: acc, status: "stopped" });
        else dropMessage(threadId, asstId);
      } else {
        const message = err instanceof Error && err.message ? err.message : "发送失败，请再试一次。";
        patchMessage(threadId, asstId, {
          content: acc || message,
          status: acc ? "done" : "error",
        });
      }
    } finally {
      setSending(false);
      abortRef.current = null;
    }
  }

  async function send(raw: string) {
    const text = raw.trim();
    if (!ready || busyRef.current || !text || text.length > MAX_INPUT) return;
    const threadId = activeId ?? newThread();
    const thread = useChatStore.getState().threads.find((t) => t.id === threadId);
    if (!thread) return;
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: text,
      createdAt: Date.now(),
      status: "done",
    };
    commitExchange(threadId, [userMsg], text);
    setDraft("");
    if (boxRef.current) boxRef.current.style.height = "0px";
    const history = historyOf([...thread.messages, userMsg]);
    busyRef.current = true;
    try {
      await run(threadId, history);
    } finally {
      busyRef.current = false;
    }
    focusComposer();
  }

  async function retry(thread: Thread) {
    if (busyRef.current) return;
    const last = thread.messages[thread.messages.length - 1];
    if (!last || last.role !== "assistant") return;
    const history = historyOf(thread.messages.slice(0, -1));
    if (history.length === 0 || history[history.length - 1]?.role !== "user") return;
    dropMessage(thread.id, last.id);
    busyRef.current = true;
    try {
      await run(thread.id, history);
    } finally {
      busyRef.current = false;
    }
  }

  async function copyMessage(id: string, content: string) {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedId(id);
      window.setTimeout(() => setCopiedId((cur) => (cur === id ? null : cur)), 1400);
    } catch {
      setCopiedId(null);
    }
  }

  const nearLimit = draft.length > 3200;

  return (
    <div className="flex h-dvh bg-ink text-fg">
      {sidebarOpen ? (
        <button
          type="button"
          aria-label="关闭对话列表"
          className="fixed inset-0 z-30 bg-ink/80 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      ) : null}

      <aside
        className={
          "fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-line bg-paper md:static md:z-0 md:translate-x-0 " +
          (sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0")
        }
      >
        <div className="flex items-center justify-between gap-3 px-4 py-4">
          <div className="min-w-0">
            <p className="font-serif text-2xl leading-none">墨谈</p>
            <p className="mt-1 text-sm text-muted">和 Grok 说说话</p>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md text-muted hover:bg-sheet hover:text-fg md:hidden"
            aria-label="关闭"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="px-3">
          <button
            type="button"
            onClick={startNew}
            className="flex min-h-11 w-full items-center justify-center gap-2 rounded-md bg-amber px-3 text-sm font-medium text-ink"
          >
            <Plus className="size-4" />
            新的对谈
          </button>
        </div>

        <nav className="scroll-thin mt-3 flex-1 overflow-y-auto px-2 pb-3" aria-label="对话列表">
          {ordered.length === 0 ? (
            <p className="px-2 py-6 text-sm text-faint">还没有对谈。</p>
          ) : (
            <ul className="space-y-1">
              {ordered.map((thread) => {
                const selected = thread.id === activeId;
                return (
                  <li key={thread.id}>
                    <div
                      className={
                        "group flex items-stretch rounded-md " +
                        (selected ? "bg-sheet" : "hover:bg-sheet")
                      }
                    >
                      <button
                        type="button"
                        onClick={() => openThread(thread.id)}
                        className="min-h-11 min-w-0 flex-1 px-3 py-2 text-left"
                      >
                        <span className="block truncate text-sm">{thread.title}</span>
                        <span className="mt-0.5 block text-xs text-faint tabular-nums">
                          {formatWhen(thread.updatedAt)}
                        </span>
                      </button>
                      {pendingDelete === thread.id ? (
                        <button
                          type="button"
                          className="min-h-11 px-3 text-sm text-amber"
                          onClick={() => {
                            removeThread(thread.id);
                            setPendingDelete(null);
                          }}
                        >
                          删除
                        </button>
                      ) : (
                        <button
                          type="button"
                          aria-label={`删除${thread.title}`}
                          className="grid w-11 place-items-center text-faint hover:text-fg"
                          onClick={() => setPendingDelete(thread.id)}
                        >
                          <Trash2 className="size-4" />
                        </button>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </nav>

        <p className="border-t border-line px-4 py-3 text-xs text-faint">对话只留在这台设备上</p>
      </aside>

      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-line px-2 py-2 md:px-4">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md text-fg hover:bg-paper md:hidden"
            aria-label="打开对话列表"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-serif text-lg md:text-xl">
              <span className="md:hidden">墨谈</span>
              <span className="hidden md:inline">{active?.title && active.messages.length ? active.title : "墨谈"}</span>
            </p>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md text-fg hover:bg-paper"
            aria-label="新的对谈"
            onClick={startNew}
          >
            <Plus className="size-5" />
          </button>
        </header>

        <div
          ref={scrollerRef}
          className="scroll-thin flex-1 overflow-y-auto"
          onScroll={(event) => {
            const el = event.currentTarget;
            stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
          }}
        >
          {!active || active.messages.length === 0 ? (
            <div className="mx-auto flex min-h-full w-full max-w-xl flex-col px-5 py-8">
              <div className="my-auto">
                <p className="font-serif text-4xl leading-tight text-balance">把念头放在这里</p>
                <p className="mt-3 max-w-sm text-muted text-pretty">
                  和 Grok 慢慢说。可以很短，也可以把一件事讲完。
                </p>
                <div className="mt-8 grid gap-2 sm:grid-cols-2">
                  {STARTERS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      disabled={!ready || sending}
                      onClick={() => void send(prompt)}
                      className="min-h-11 rounded-md border border-line bg-paper px-4 py-3 text-left text-sm text-fg hover:border-amber disabled:opacity-50"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <ol className="mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-6 md:px-6">
              {active.messages.map((message, index) => {
                const last = index === active.messages.length - 1;
                if (message.role === "user") {
                  return (
                    <li key={message.id} className="flex flex-col items-end gap-1">
                      <p className="max-w-lg whitespace-pre-wrap break-words rounded-lg bg-sheet px-4 py-3 text-pretty">
                        {message.content}
                      </p>
                      <time className="px-1 text-xs text-faint tabular-nums" dateTime={new Date(message.createdAt).toISOString()}>
                        {formatTimestamp(message.createdAt)}
                      </time>
                    </li>
                  );
                }
                return (
                  <li key={message.id}>
                    <div className="mb-2 flex items-center gap-2 text-amber">
                      <span className="grid size-6 place-items-center rounded-sm border border-amber font-serif text-xs">
                        墨
                      </span>
                      <span className="text-sm">墨谈</span>
                      {message.status === "stopped" ? (
                        <span className="text-xs text-faint">已停笔</span>
                      ) : null}
                    </div>
                    {message.status === "streaming" && !message.content ? (
                      <p className="text-muted">
                        落笔
                        <span className="caret" aria-hidden />
                      </p>
                    ) : (
                      <div className="font-serif text-lg leading-relaxed">
                        <Markdown source={message.content} />
                        {message.status === "streaming" ? <span className="caret" aria-hidden /> : null}
                      </div>
                    )}
                    {message.status === "error" ? (
                      <p className="mt-2 text-sm text-muted">没能写完。</p>
                    ) : null}
                    <time className="mt-2 block text-xs text-faint tabular-nums" dateTime={new Date(message.createdAt).toISOString()}>
                      {formatTimestamp(message.createdAt)}
                    </time>
                    {message.content && message.status !== "streaming" ? (
                      <div className="mt-2 flex items-center gap-1">
                        <button
                          type="button"
                          className="inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm text-faint hover:text-fg"
                          onClick={() => void copyMessage(message.id, message.content)}
                        >
                          {copiedId === message.id ? <Check className="size-4" /> : <Copy className="size-4" />}
                          {copiedId === message.id ? "已复制" : "复制"}
                        </button>
                        {last ? (
                          <button
                            type="button"
                            className="inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm text-faint hover:text-fg"
                            onClick={() => void retry(active)}
                            disabled={sending}
                          >
                            <RotateCcw className="size-4" />
                            再写一次
                          </button>
                        ) : null}
                      </div>
                    ) : null}
                  </li>
                );
              })}
            </ol>
          )}
        </div>

        <div className="composer-pad border-t border-line px-3 pt-3 md:px-6">
          <div className="mx-auto w-full max-w-2xl">
            <div className="mb-2 grid grid-cols-3 gap-1 rounded-md bg-paper p-1" role="group" aria-label="语气">
              {TONES.map((tone) => {
                const on = (active?.tone ?? "chat") === tone.id;
                return (
                  <button
                    key={tone.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => {
                      if (!activeId) newThread();
                      setTone(tone.id);
                    }}
                    className={
                      "min-h-11 rounded-sm text-sm " +
                      (on ? "bg-sheet text-fg" : "text-muted hover:text-fg")
                    }
                  >
                    {tone.label}
                  </button>
                );
              })}
            </div>

            <form
              className="flex items-end gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                if (sending) abortRef.current?.abort();
                else void send(draft);
              }}
            >
              <label className="min-w-0 flex-1">
                <span className="sr-only">写下来</span>
                <textarea
                  ref={boxRef}
                  value={draft}
                  rows={1}
                  maxLength={MAX_INPUT}
                  placeholder="写下来…"
                  disabled={!ready}
                  suppressHydrationWarning
                  onChange={(event) => {
                    setDraft(event.target.value);
                    resizeBox();
                  }}
                  onKeyDown={(event) => {
                    if (event.key !== "Enter" || event.shiftKey) return;
                    if (event.nativeEvent.isComposing || event.keyCode === 229) return;
                    if (window.matchMedia("(pointer: coarse)").matches) return;
                    event.preventDefault();
                    void send(draft);
                  }}
                  className="max-h-40 min-h-11 w-full resize-none rounded-lg border border-line bg-paper px-4 py-3 text-base text-fg outline-none placeholder:text-faint focus:border-amber"
                />
              </label>
              <button
                type="submit"
                aria-label={sending ? "停止" : "发送"}
                disabled={!sending && (!ready || !draft.trim())}
                className="grid size-11 shrink-0 place-items-center rounded-lg bg-amber text-ink disabled:opacity-40"
              >
                {sending ? <Square className="size-4" /> : <ArrowUp className="size-5" />}
              </button>
            </form>
            <p className="mt-2 flex justify-between text-xs text-faint">
              <span className="hidden sm:inline">Enter 发送 · Shift+Enter 换行</span>
              <span className="sm:hidden">{sending ? "正在写" : "点箭头发送"}</span>
              <span className={"tabular-nums " + (nearLimit ? "text-amber" : "")}>
                {nearLimit ? `${draft.length}/${MAX_INPUT}` : ""}
              </span>
            </p>
            <p className="sr-only" aria-live="polite">
              {sending ? "正在写" : ""}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
