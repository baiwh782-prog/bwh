import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as Copy, i as Square, l as Check, o as Plus, r as Trash2, s as Menu, t as X, u as ArrowUp } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-0XyiFNLf.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKO5Ks4M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function parseBlocks(source) {
	const lines = source.replace(/\r\n/g, "\n").split("\n");
	const blocks = [];
	let i = 0;
	while (i < lines.length) {
		const line = lines[i] ?? "";
		const fence = /^```([\w-]*)\s*$/.exec(line);
		if (fence) {
			const lang = fence[1] ?? "";
			const buf = [];
			i += 1;
			while (i < lines.length && !/^```\s*$/.test(lines[i] ?? "")) {
				buf.push(lines[i] ?? "");
				i += 1;
			}
			if (i < lines.length) i += 1;
			blocks.push({
				type: "code",
				lang,
				text: buf.join("\n")
			});
			continue;
		}
		if (!line.trim()) {
			i += 1;
			continue;
		}
		const heading = /^(#{1,3})\s+(.+)$/.exec(line);
		if (heading) {
			const marks = heading[1] ?? "#";
			const level = Math.min(marks.length, 3);
			blocks.push({
				type: "heading",
				level,
				text: heading[2] ?? ""
			});
			i += 1;
			continue;
		}
		if (/^>\s?/.test(line)) {
			const buf = [];
			while (i < lines.length && /^>\s?/.test(lines[i] ?? "")) {
				buf.push((lines[i] ?? "").replace(/^>\s?/, ""));
				i += 1;
			}
			blocks.push({
				type: "quote",
				text: buf.join("\n")
			});
			continue;
		}
		const unordered = /^[-*]\s+/.test(line);
		const ordered = /^\d+\.\s+/.test(line);
		if (unordered || ordered) {
			const items = [];
			const pattern = unordered ? /^[-*]\s+/ : /^\d+\.\s+/;
			while (i < lines.length && pattern.test(lines[i] ?? "")) {
				items.push((lines[i] ?? "").replace(pattern, ""));
				i += 1;
			}
			blocks.push({
				type: "list",
				ordered,
				items
			});
			continue;
		}
		const buf = [line];
		i += 1;
		while (i < lines.length && (lines[i] ?? "").trim() && !/^```/.test(lines[i] ?? "") && !/^#{1,3}\s+/.test(lines[i] ?? "") && !/^>\s?/.test(lines[i] ?? "") && !/^[-*]\s+/.test(lines[i] ?? "") && !/^\d+\.\s+/.test(lines[i] ?? "")) {
			buf.push(lines[i] ?? "");
			i += 1;
		}
		blocks.push({
			type: "p",
			text: buf.join("\n")
		});
	}
	return blocks;
}
function renderInline(text, keyPrefix) {
	const re = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`\n]+`|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g;
	const nodes = [];
	let last = 0;
	let match;
	let n = 0;
	while (match = re.exec(text)) {
		if (match.index > last) nodes.push(text.slice(last, match.index));
		const token = match[0];
		const key = `${keyPrefix}-${n++}`;
		if (token.startsWith("**")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: token.slice(2, -2) }, key));
		else if (token.startsWith("`")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-sm bg-ink px-1 py-0.5 text-amber",
			children: token.slice(1, -1)
		}, key));
		else if (token.startsWith("[")) {
			const link = /^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/.exec(token);
			const href = link?.[2] ?? "";
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				target: "_blank",
				rel: "noreferrer noopener",
				className: "text-amber underline decoration-line underline-offset-2",
				children: link?.[1] ?? href
			}, key));
		} else nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: token.slice(1, -1) }, key));
		last = match.index + token.length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return nodes;
}
function CodeBlock({ lang, text }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function copy() {
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1400);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-md border border-line bg-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 border-b border-line px-3 py-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-faint",
				children: lang || "代码"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void copy(),
				className: "inline-flex min-h-11 items-center gap-1 rounded-sm px-2 text-xs text-muted hover:text-fg",
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), copied ? "已复制" : "复制"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "scroll-thin overflow-x-auto px-3 py-3 text-sm leading-relaxed",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: text })
		})]
	});
}
function Markdown({ source }) {
	const blocks = parseBlocks(source);
	if (blocks.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 break-words",
		children: blocks.map((block, index) => {
			const key = `${block.type}-${index}`;
			if (block.type === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
				lang: block.lang,
				text: block.text
			}, key);
			if (block.type === "heading") {
				const className = block.level === 1 ? "font-serif text-xl font-semibold text-balance" : "font-serif text-lg font-semibold text-balance";
				if (block.level === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className,
					children: renderInline(block.text, key)
				}, key);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className,
					children: renderInline(block.text, key)
				}, key);
			}
			if (block.type === "quote") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "border-l-2 border-amber pl-3 text-muted",
				children: renderInline(block.text, key)
			}, key);
			if (block.type === "list") {
				const ListTag = block.ordered ? "ol" : "ul";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTag, {
					className: block.ordered ? "list-decimal space-y-1 pl-5" : "list-disc space-y-1 pl-5",
					children: block.items.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: renderInline(item, `${key}-${itemIndex}`) }, `${key}-${itemIndex}`))
				}, key);
			}
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap text-pretty",
				children: renderInline(block.text, key)
			}, key);
		})
	});
}
function endpoint() {
	if (typeof window === "undefined") return "/api/chat";
	return `${previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}/api/chat`;
}
async function streamChat(input, signal, onDelta) {
	const res = await fetch(endpoint(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(input),
		signal
	});
	const contentType = res.headers.get("content-type") ?? "";
	if (!res.ok || !contentType.includes("text/event-stream") || !res.body) {
		let message = "发送失败，请再试一次。";
		try {
			const data = await res.json();
			if (data.error) message = data.error;
		} catch {}
		throw new Error(message);
	}
	const reader = res.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	while (true) {
		const { done, value } = await reader.read();
		if (done) break;
		buffer += decoder.decode(value, { stream: true });
		const chunks = buffer.split("\n\n");
		buffer = chunks.pop() ?? "";
		for (const chunk of chunks) {
			const line = chunk.split("\n").map((l) => l.trim()).find((l) => l.startsWith("data:"));
			if (!line) continue;
			const data = line.slice(5).trim();
			if (!data || data === "[DONE]") return;
			let payload;
			try {
				payload = JSON.parse(data);
			} catch {
				continue;
			}
			if (payload.error) throw new Error(payload.error);
			if (payload.delta) onDelta(payload.delta);
		}
	}
}
var MAX_THREADS = 40;
function uid() {
	return crypto.randomUUID();
}
function titleFrom(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (!clean) return "未命名";
	return clean.length > 18 ? `${clean.slice(0, 18)}…` : clean;
}
function touch(thread, patch) {
	return {
		...thread,
		...patch,
		updatedAt: Date.now()
	};
}
var useChatStore = create()(persist((set, get) => ({
	threads: [],
	activeId: null,
	newThread: () => {
		const blank = get().threads.find((t) => t.messages.length === 0);
		if (blank) {
			set({ activeId: blank.id });
			return blank.id;
		}
		const id = uid();
		set({
			threads: [{
				id,
				title: "未命名",
				tone: "chat",
				messages: [],
				updatedAt: Date.now()
			}, ...get().threads].slice(0, MAX_THREADS),
			activeId: id
		});
		return id;
	},
	setActive: (id) => set({ activeId: id }),
	setTone: (tone) => {
		const { activeId, threads } = get();
		if (!activeId) return;
		set({ threads: threads.map((t) => t.id === activeId ? touch(t, { tone }) : t) });
	},
	removeThread: (id) => {
		const threads = get().threads.filter((t) => t.id !== id);
		set({
			threads,
			activeId: get().activeId === id ? threads[0]?.id ?? null : get().activeId
		});
	},
	commitExchange: (threadId, messages, title) => {
		set({ threads: get().threads.map((t) => {
			if (t.id !== threadId) return t;
			return touch(t, {
				title: title && (t.title === "未命名" || t.messages.length === 0) ? titleFrom(title) : t.title,
				messages: [...t.messages, ...messages].slice(-80)
			});
		}) });
	},
	patchMessage: (threadId, messageId, patch) => {
		set({ threads: get().threads.map((t) => {
			if (t.id !== threadId) return t;
			return touch(t, { messages: t.messages.map((m) => m.id === messageId ? {
				...m,
				...patch
			} : m) });
		}) });
	},
	dropMessage: (threadId, messageId) => {
		set({ threads: get().threads.map((t) => {
			if (t.id !== threadId) return t;
			return touch(t, { messages: t.messages.filter((m) => m.id !== messageId) });
		}) });
	}
}), {
	name: "motan-threads-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		threads: s.threads,
		activeId: s.activeId
	})
}));
function formatWhen(ts) {
	const diff = Date.now() - ts;
	const min = Math.round(diff / 6e4);
	if (min < 1) return "刚刚";
	if (min < 60) return `${min} 分钟前`;
	const hr = Math.round(min / 60);
	if (hr < 24) return `${hr} 小时前`;
	const day = Math.round(hr / 24);
	if (day === 1) return "昨天";
	if (day < 7) return `${day} 天前`;
	const d = new Date(ts);
	return `${d.getMonth() + 1}月${d.getDate()}日`;
}
var TONES = [
	{
		id: "brief",
		label: "速答"
	},
	{
		id: "chat",
		label: "闲谈"
	},
	{
		id: "deep",
		label: "深谈"
	}
];
var STARTERS = [
	"帮我把一段话改得更干净",
	"用一个生活里的比喻讲清楚一件难事",
	"我在两个选择之间卡住了",
	"给今天写一句不矫情的小结"
];
var MAX_INPUT = 4e3;
function historyOf(messages) {
	return messages.filter((m) => m.content.trim() && m.status !== "streaming" && m.status !== "error").slice(-16).map((m) => ({
		role: m.role,
		content: m.content
	}));
}
function ChatApp() {
	const threads = useChatStore((s) => s.threads);
	const activeId = useChatStore((s) => s.activeId);
	const newThread = useChatStore((s) => s.newThread);
	const setActive = useChatStore((s) => s.setActive);
	const setTone = useChatStore((s) => s.setTone);
	const removeThread = useChatStore((s) => s.removeThread);
	const commitExchange = useChatStore((s) => s.commitExchange);
	const patchMessage = useChatStore((s) => s.patchMessage);
	const dropMessage = useChatStore((s) => s.dropMessage);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const abortRef = (0, import_react.useRef)(null);
	const busyRef = (0, import_react.useRef)(false);
	const scrollerRef = (0, import_react.useRef)(null);
	const stickRef = (0, import_react.useRef)(true);
	const boxRef = (0, import_react.useRef)(null);
	const active = threads.find((t) => t.id === activeId) ?? null;
	const ordered = [...threads].sort((a, b) => b.updatedAt - a.updatedAt);
	(0, import_react.useEffect)(() => {
		let alive = true;
		Promise.resolve(useChatStore.persist.rehydrate()).then(() => {
			if (!alive) return;
			const state = useChatStore.getState();
			if (!state.threads.some((t) => t.id === state.activeId)) useChatStore.setState({ activeId: state.threads[0]?.id ?? null });
			setReady(true);
		});
		return () => {
			alive = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!stickRef.current) return;
		const el = scrollerRef.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [active?.messages, sending]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") setSidebarOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function focusComposer() {
		if (window.matchMedia("(pointer: coarse)").matches) return;
		boxRef.current?.focus();
	}
	function resizeBox() {
		const el = boxRef.current;
		if (!el) return;
		el.style.height = "0px";
		el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
	}
	function openThread(id) {
		setActive(id);
		setDraft("");
		setSidebarOpen(false);
		setPendingDelete(null);
		stickRef.current = true;
		focusComposer();
	}
	function startNew() {
		const id = newThread();
		setDraft("");
		setSidebarOpen(false);
		setPendingDelete(null);
		stickRef.current = true;
		useChatStore.setState({ activeId: id });
		focusComposer();
	}
	async function run(threadId, history) {
		const tone = useChatStore.getState().threads.find((t) => t.id === threadId)?.tone ?? "chat";
		const asstId = crypto.randomUUID();
		commitExchange(threadId, [{
			id: asstId,
			role: "assistant",
			content: "",
			createdAt: Date.now(),
			status: "streaming"
		}]);
		stickRef.current = true;
		setSending(true);
		const ac = new AbortController();
		abortRef.current = ac;
		let acc = "";
		try {
			await streamChat({
				tone,
				messages: history
			}, ac.signal, (delta) => {
				acc += delta;
				patchMessage(threadId, asstId, {
					content: acc,
					status: "streaming"
				});
			});
			patchMessage(threadId, asstId, {
				content: acc || "（没有写下内容）",
				status: acc ? "done" : "error"
			});
		} catch (err) {
			if (ac.signal.aborted) {
				if (acc) patchMessage(threadId, asstId, {
					content: acc,
					status: "stopped"
				});
				else dropMessage(threadId, asstId);
			} else {
				const message = err instanceof Error && err.message ? err.message : "发送失败，请再试一次。";
				patchMessage(threadId, asstId, {
					content: acc || message,
					status: acc ? "done" : "error"
				});
			}
		} finally {
			setSending(false);
			abortRef.current = null;
		}
	}
	async function send(raw) {
		const text = raw.trim();
		if (!ready || busyRef.current || !text || text.length > MAX_INPUT) return;
		const threadId = activeId ?? newThread();
		const thread = useChatStore.getState().threads.find((t) => t.id === threadId);
		if (!thread) return;
		const userMsg = {
			id: crypto.randomUUID(),
			role: "user",
			content: text,
			createdAt: Date.now(),
			status: "done"
		};
		commitExchange(threadId, [userMsg], text);
		setDraft("");
		if (boxRef.current) boxRef.current.style.height = "0px";
		const history = historyOf([...thread.messages, userMsg]);
		busyRef.current = true;
		try {
			await run(threadId, history);
		} finally {
			busyRef.current = false;
		}
		focusComposer();
	}
	async function retry(thread) {
		if (busyRef.current) return;
		const last = thread.messages[thread.messages.length - 1];
		if (!last || last.role !== "assistant") return;
		const history = historyOf(thread.messages.slice(0, -1));
		if (history.length === 0 || history[history.length - 1]?.role !== "user") return;
		dropMessage(thread.id, last.id);
		busyRef.current = true;
		try {
			await run(thread.id, history);
		} finally {
			busyRef.current = false;
		}
	}
	async function copyMessage(id, content) {
		try {
			await navigator.clipboard.writeText(content);
			setCopiedId(id);
			window.setTimeout(() => setCopiedId((cur) => cur === id ? null : cur), 1400);
		} catch {
			setCopiedId(null);
		}
	}
	const nearLimit = draft.length > 3200;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh bg-ink text-fg",
		children: [
			sidebarOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "关闭对话列表",
				className: "fixed inset-0 z-30 bg-ink/80 md:hidden",
				onClick: () => setSidebarOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-line bg-paper transition-transform duration-200 motion-reduce:transition-none md:static md:z-0 md:translate-x-0 " + (sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl leading-none",
								children: "墨谈"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "和 Grok 说说话"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-md text-muted hover:bg-sheet hover:text-fg md:hidden",
							"aria-label": "关闭",
							onClick: () => setSidebarOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: startNew,
							className: "flex min-h-11 w-full items-center justify-center gap-2 rounded-md bg-amber px-3 text-sm font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "新的对谈"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "scroll-thin mt-3 flex-1 overflow-y-auto px-2 pb-3",
						"aria-label": "对话列表",
						children: ordered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 py-6 text-sm text-faint",
							children: "还没有对谈。"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1",
							children: ordered.map((thread) => {
								const selected = thread.id === activeId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group flex items-stretch rounded-md " + (selected ? "bg-sheet" : "hover:bg-sheet"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => openThread(thread.id),
										className: "min-h-11 min-w-0 flex-1 px-3 py-2 text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-sm",
											children: thread.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block text-xs text-faint tabular-nums",
											children: formatWhen(thread.updatedAt)
										})]
									}), pendingDelete === thread.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 px-3 text-sm text-amber",
										onClick: () => {
											removeThread(thread.id);
											setPendingDelete(null);
										},
										children: "删除"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `删除${thread.title}`,
										className: "grid w-11 place-items-center text-faint hover:text-fg",
										onClick: () => setPendingDelete(thread.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								}) }, thread.id);
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "border-t border-line px-4 py-3 text-xs text-faint",
						children: "对话只留在这台设备上"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center gap-2 border-b border-line px-2 py-2 md:px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-md text-fg hover:bg-paper md:hidden",
								"aria-label": "打开对话列表",
								onClick: () => setSidebarOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-serif text-lg md:text-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "md:hidden",
										children: "墨谈"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden md:inline",
										children: active?.title && active.messages.length ? active.title : "墨谈"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-md text-fg hover:bg-paper",
								"aria-label": "新的对谈",
								onClick: startNew,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scrollerRef,
						className: "scroll-thin flex-1 overflow-y-auto",
						onScroll: (event) => {
							const el = event.currentTarget;
							stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
						},
						children: !active || active.messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex min-h-full w-full max-w-xl flex-col px-5 py-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "my-auto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-serif text-4xl leading-tight text-balance",
										children: "把念头放在这里"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 max-w-sm text-muted text-pretty",
										children: "和 Grok 慢慢说。可以很短，也可以把一件事讲完。"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-8 grid gap-2 sm:grid-cols-2",
										children: STARTERS.map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: !ready || sending,
											onClick: () => void send(prompt),
											className: "min-h-11 rounded-md border border-line bg-paper px-4 py-3 text-left text-sm text-fg hover:border-amber disabled:opacity-50",
											children: prompt
										}, prompt))
									})
								]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-6 md:px-6",
							children: active.messages.map((message, index) => {
								const last = index === active.messages.length - 1;
								if (message.role === "user") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "msg-in flex justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-lg whitespace-pre-wrap break-words rounded-lg bg-sheet px-4 py-3 text-pretty",
										children: message.content
									})
								}, message.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "msg-in",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 flex items-center gap-2 text-amber",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "grid size-6 place-items-center rounded-sm border border-amber font-serif text-xs",
													children: "墨"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm",
													children: "墨谈"
												}),
												message.status === "stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-faint",
													children: "已停笔"
												}) : null
											]
										}),
										message.status === "streaming" && !message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-muted",
											children: ["落笔", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "caret",
												"aria-hidden": true
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-serif text-lg leading-relaxed",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { source: message.content }), message.status === "streaming" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "caret",
												"aria-hidden": true
											}) : null]
										}),
										message.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted",
											children: "没能写完。"
										}) : null,
										message.content && message.status !== "streaming" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm text-faint hover:text-fg",
												onClick: () => void copyMessage(message.id, message.content),
												children: [copiedId === message.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copiedId === message.id ? "已复制" : "复制"]
											}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm text-faint hover:text-fg",
												onClick: () => void retry(active),
												disabled: sending,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "再写一次"]
											}) : null]
										}) : null
									]
								}, message.id);
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "composer-pad border-t border-line px-3 pt-3 md:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto w-full max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-2 grid grid-cols-3 gap-1 rounded-md bg-paper p-1",
									role: "group",
									"aria-label": "语气",
									children: TONES.map((tone) => {
										const on = (active?.tone ?? "chat") === tone.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": on,
											onClick: () => {
												if (!activeId) newThread();
												setTone(tone.id);
											},
											className: "min-h-11 rounded-sm text-sm " + (on ? "bg-sheet text-fg" : "text-muted hover:text-fg"),
											children: tone.label
										}, tone.id);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									className: "flex items-end gap-2",
									onSubmit: (event) => {
										event.preventDefault();
										if (sending) abortRef.current?.abort();
										else send(draft);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "写下来"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											ref: boxRef,
											value: draft,
											rows: 1,
											maxLength: MAX_INPUT,
											placeholder: "写下来…",
											disabled: !ready,
											suppressHydrationWarning: true,
											onChange: (event) => {
												setDraft(event.target.value);
												resizeBox();
											},
											onKeyDown: (event) => {
												if (event.key !== "Enter" || event.shiftKey) return;
												if (event.nativeEvent.isComposing || event.keyCode === 229) return;
												if (window.matchMedia("(pointer: coarse)").matches) return;
												event.preventDefault();
												send(draft);
											},
											className: "max-h-40 min-h-11 w-full resize-none rounded-lg border border-line bg-paper px-4 py-3 text-base text-fg outline-none placeholder:text-faint focus:border-amber"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										"aria-label": sending ? "停止" : "发送",
										disabled: !sending && (!ready || !draft.trim()),
										className: "grid size-11 shrink-0 place-items-center rounded-lg bg-amber text-ink disabled:opacity-40",
										children: sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 flex justify-between text-xs text-faint",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Enter 发送 · Shift+Enter 换行"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sm:hidden",
											children: sending ? "正在写" : "点箭头发送"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums " + (nearLimit ? "text-amber" : ""),
											children: nearLimit ? `${draft.length}/${MAX_INPUT}` : ""
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "sr-only",
									"aria-live": "polite",
									children: sending ? "正在写" : ""
								})
							]
						})
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatApp, {});
}
//#endregion
export { Home as component };
