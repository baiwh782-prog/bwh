//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHHKplKO.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/chat"],
		preloads: ["/assets/index-C53U7c0J.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C53U7c0J.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bv6WxjyS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
